<li>
    <a style="background-color:<?php echo esc_attr($regionBgColor); ?>" href="<?php the_permalink(); ?>">
        <h2 style="color:<?php echo esc_attr($textColor); ?>"><?php the_title(); ?></h2>
    </a>
</li>