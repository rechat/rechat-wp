jQuery(document).ready(function ($) {
    // function init() {
    //     loadTotalHousesCount(getFilters()); // Initial load with filters
    //     setupEventListeners();
    // }

    // function setupEventListeners() {
    //     $('#pagination-controls').on('click', '.pagination-btn', function () {
    //         currentPage = $(this).data('page');
    //         loadHouses(currentPage, getFilters(), housesPerPage)
    //             .then(data => {
    //                 renderHouses(data.data);
    //                 totalHouses = rchTotalHouses; // Assume this is part of your data response
    //                 generatePaginationControls(totalHouses, currentPage, housesPerPage);
    //             });
    //     });

    //     $('#apply-filters').on('click', function () {
    //         currentPage = 1; // Reset to first page
    //         loadTotalHousesCount(getFilters());
    //     });
    // }



    // init();

});
